1:"$Sreact.fragment"
2:I[7121,[],""]
3:I[4581,[],""]
:HL["/_next/static/css/ce9048e28db1d051.css","style"]
0:{"rsc":["$","$1","c",{"children":[[["$","link","0",{"rel":"stylesheet","href":"/_next/static/css/ce9048e28db1d051.css","precedence":"next"}]],["$","html",null,{"lang":"en","className":"__variable_246ccd __variable_c29908 h-full antialiased","children":["$","body",null,{"className":"flex min-h-full flex-col bg-background text-foreground","children":["$","$L2",null,{"parallelRouterKey":"children","template":["$","$L3",null,{}]}]}]}]]}],"isPartial":false,"staleTime":300,"varyParams":null,"buildId":"YcA1CYLI9cyrQdaX1zXZE"}
